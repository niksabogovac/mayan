class AlreadyScheduled(Exception):
    pass
