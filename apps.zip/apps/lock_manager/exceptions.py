class LockError(Exception):
    pass
