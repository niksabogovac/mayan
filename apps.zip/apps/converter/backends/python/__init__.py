from PIL import Image

Image.init()
