from django.dispatch import Signal

pre_collectstatic = Signal()
