class AlreadyRegistered(Exception):
    pass
