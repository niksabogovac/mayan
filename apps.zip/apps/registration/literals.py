FORM_SUBMIT_URL = 'https://docs.google.com/spreadsheet/formResponse'
FORM_KEY = 'dHp4cFBZNHNtc0xwcW9IazVXY1ZmVWc6MQ'
FORM_RECEIVER_FIELD = 'entry.0.single'
TIMEOUT = 5
