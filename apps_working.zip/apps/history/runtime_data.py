history_types_dict = {}
