def process_job(func, *args, **kwargs):
    return func(*args, **kwargs)
