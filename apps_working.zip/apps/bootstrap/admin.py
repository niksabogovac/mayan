from __future__ import absolute_import

from django.contrib import admin

from .models import BootstrapSetup

admin.site.register(BootstrapSetup)
