class MaxSuffixCountReached(Exception):
    """
    Raised when there are too many documents with the same filename in the
    same node/directory
    """
    pass
