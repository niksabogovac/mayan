from django.utils.translation import ugettext_lazy as _

DEFAULT_CSV_FILENAME = u'folder_export.csv'
